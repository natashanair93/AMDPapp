# AMDP prototype backlog

## Landing page (AMDP Home.dc.html)
- [ ] Workflow content: finalize the six "What people do here" workflows (titles, descriptions, "Helps" audience, Start destinations)
- [ ] Section heading consistency: align eyebrow, heading size/weight, subtitle and alignment across Workflows, New arrivals and Featured products
- [ ] Color consistency: settle the domain color per entity type (app, SDK, model, MCP server, skill, glossary) and apply it the same way to icons, eyebrows, pills and CTAs
- [ ] Consistent product and service tile: one tile pattern (icon, name, type, description, social cues, pin, launch) used everywhere products and services appear (search results, recently searched, relevant, featured, new arrivals)
- [ ] Featured products structure: define the content model for each product (name, type, description, social cues, CTA, launch URL) and which social cues to show

## Home page day 0.5
- [ ] Recently searched tiles: refine layout and content (how many searches and results to show, tile design, "See all results" behavior)
- [ ] Relevant to your search tiles: refine layout, how relevance is chosen and explained, and tile design

## Interactions
- [ ] Launch button behavior: define what clicking Launch does (open external app in new tab, confirmation or access-request step, loading state) and how it updates Recent activity and the side nav
- [ ] Chat box pattern: move suggestion pills inside the chat box everywhere (Home landing included), matching the search results page
- [ ] CTA label by type: SDKs use "Open docs" instead of "Launch"; define the CTA for the other types too

## Open questions from kickoff
- [ ] Screens beyond the landing page (search results, app detail, category, my apps)
- [ ] Item types in the store (apps, SDKs, agents, MCP servers, models, APIs, datasets)
- [ ] Search by intent behavior (ranked list vs. agent answer vs. intent chips)
- [ ] Card click behavior (launch immediately vs. detail page first)
- [ ] Real app names and launch links
